#pragma once
#include <behaviortree_cpp_v3/condition_node.h>

class IsGoalReached : public BT::ConditionNode
{
public:
    // Constructor
    IsGoalReached(const std::string& name, const BT::NodeConfiguration& config)
        : BT::ConditionNode(name, config) {}

    // Ports (tidak ada input/output di contoh sederhana)
    static BT::PortsList providedPorts() { return {}; }

    // Tick function
    BT::NodeStatus tick() override
    {
        // Ganti logika ini dengan pengecekan goal robot
        bool goal_reached = false; // contoh: false berarti goal belum tercapai

        if (goal_reached)
            return BT::NodeStatus::SUCCESS;
        else
            return BT::NodeStatus::FAILURE;
    }
};

#!/usr/bin/env python3

from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    
    # Get package directory
    bt_controller_dir = get_package_share_directory('bt_controller')
    
    # Path ke BT XML file
    bt_xml_path = os.path.join(bt_controller_dir, 'bt_xml', 'navigation_bt.xml')
    
    # Path ke world file (sesuaikan dengan lokasi world file Anda)
    world_file = os.path.join(bt_controller_dir, 'worlds', 'bt_maze_world.world')
    
    return LaunchDescription([
        
        # Launch Gazebo dengan world
        ExecuteProcess(
            cmd=['gazebo', '--verbose', world_file],
            output='screen'
        ),
        
        # Launch BT Controller Node
        Node(
            package='bt_controller',
            executable='bt_controller_node',
            name='bt_controller',
            output='screen',
            parameters=[{
                'bt_xml': bt_xml_path
            }]
        ),
        
    ])
